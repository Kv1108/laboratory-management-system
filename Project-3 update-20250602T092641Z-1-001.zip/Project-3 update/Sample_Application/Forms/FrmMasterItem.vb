Public Class FrmMasterItem
    Dim AddFlag As Int16 = 1
    Dim EditFlag As Int16 = 0
    Dim Aname As String = ""
    Private Sub FrmEmpMasterGroup_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        NGridFormating(DataItem)
        CmdCancel_Click(sender, e)
    End Sub
    Private Sub TxtIName_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtBName.KeyDown, CmdCancel.KeyDown, CmdDelete.KeyDown, CmdExit.KeyDown, CmdSave.KeyDown
        If sender.Equals(TxtBName) = True And e.KeyValue = 27 Then Me.Close()
        NSetFocus(e.KeyValue)
    End Sub
    Private Sub CmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSave.Click
        Dim sql As String
        If Valid() = True Then
            If SaveMessage() = True Then
                If EditFlag = 1 Then
                    sql = "UPDATE MST_ITEM SET INAME='" & Trim(UCase(TxtBName.Text)) & "' " _
                    + "  WHERE SRNO=" & Trim(Val(LblId.Text)) & ""
                Else
                    LblId.Text = NAutoNumber("SELECT MAX(SRNO) FROM MST_ITEM")
                    sql = "INSERT INTO MST_ITEM(SRNO,INAME)VALUES(" _
                    + " " & Trim(Val(LblId.Text)) & ",'" & Trim(UCase(TxtBName.Text)) & "')"
                End If
                NExcuteQuery(sql)
                Call CmdCancel_Click(sender, e)
            End If
        End If
    End Sub
    Public Function Valid() As Boolean
        Valid = True
        If TxtBName.Text = "" Then
            TxtBName.Focus()
            InvalidMessage("Report Name")
            Valid = False
            Exit Function
        End If
        If EditFlag = 1 Then
            If UCase(TxtBName.Text) = UCase(Aname) Then
                If NFetchDataN("SELECT COUNT(INAME) FROM MST_ITEM WHERE INAME='" & Trim(UCase(TxtBName.Text)) & "'") > 1 Then
                    Valid = False
                    TxtBName.Focus()
                    NAllreadyMessage("Report Name")
                    Exit Function
                End If
            Else
                If NFetchDataN("SELECT COUNT(INAME) FROM MST_ITEM WHERE INAME='" & Trim(UCase(TxtBName.Text)) & "'") >= 1 Then
                    Valid = False
                    TxtBName.Focus()
                    NAllreadyMessage("Report Name")
                    Exit Function
                End If
            End If
        Else
            If NFetchDataN("SELECT COUNT(INAME) FROM MST_ITEM WHERE INAME='" & Trim(UCase(TxtBName.Text)) & "'") >= 1 Then
                Valid = False
                TxtBName.Focus()
                NAllreadyMessage("Report Name")
                Exit Function
            End If
        End If
    End Function
    Public Sub DisplayGrid()
        NFillDataGrid("SELECT SRNO,INAME FROM MST_ITEM", DataItem)
        DataItem.Columns(0).HeaderText = "Sr.No."
        DataItem.Columns(0).Visible = True
        DataItem.Columns(0).Width = 100
        DataItem.Columns(1).HeaderText = "Report Name"
        DataItem.Columns(1).Width = 720
        
    End Sub
    Private Sub DataItem_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataItem.CellDoubleClick
        If e.RowIndex = -1 Then Exit Sub
        If IsDBNull(DataItem.CurrentRow.Cells(0).Value) Then Exit Sub
        EditFlag = 1
        AddFlag = 0
        LblId.Text = DataItem.CurrentRow.Cells(0).Value
        TxtBName.Text = DataItem.CurrentRow.Cells(1).Value
        Aname = DataItem.CurrentRow.Cells(1).Value
        TxtBName.Focus()
    End Sub
    Private Sub CmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdDelete.Click
        If LblId.Text = "" Or LblId.Text = Val(0) Then Exit Sub
        If DeleteMessage() = True Then
            NExcuteQuery("DELETE * FROM MST_ITEM WHERE SRNO=" & Trim(Val(LblId.Text)) & "")
            Call CmdCancel_Click(sender, e)

        Else
            MsgBox("Item Name Is Use To Another Person...", MsgBoxStyle.Information, "Can't Delete")
            Call CmdCancel_Click(sender, e)
        End If
    End Sub
    Public Function DeleteValid() As Boolean
        DeleteValid = False
        If NCheckRecord("SELECT COUNT(SRNO),COUNT(INAME) FROM MST_ITEM WHERE INAME=" & Trim(Val(LblId.Text)) & "") = True Then
            DeleteValid = True
            Exit Function
        End If
    End Function
    Private Sub CmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdCancel.Click
        LblId.Text = 0
        AddFlag = 1
        EditFlag = 0
        NClearingControl(TableLayoutPanel2)
        TxtBName.Focus()
        DisplayGrid()
    End Sub
    Private Sub CmdExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdExit.Click
        Me.Close()
    End Sub
End Class
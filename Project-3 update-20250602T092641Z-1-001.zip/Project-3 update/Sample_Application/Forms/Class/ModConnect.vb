Imports System.Data.SqlClient
Imports System.Data.OleDb
Module ModConnect
    'Dim oSQLServer As New SQLDMO.SQLServer
    'Dim oBackUp As New SQLDMO.Backup
    Public con As OleDbConnection
    Private cmd As New OleDbCommand
    Private adp As New OleDbDataAdapter
    Private Trans As SqlTransaction = Nothing
    Public Sub ConnectionOpen()
        con = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\Data\SampleDatabase.mdb")
        con.Open()
    End Sub
    Public Sub ConnectionClose()
        con.Close()
    End Sub
    Public Function NFetchDataset(ByVal Query As String) As DataSet
        Dim dtp As New DataSet
        adp = New OleDbDataAdapter(Query, con)
        adp.Fill(dtp)
        NFetchDataset = dtp
    End Function
    Public Function NFetchDataD(ByVal STR As String) As Date
        cmd = New OleDbCommand(STR, con)
        If IsDBNull(cmd.ExecuteScalar()) Then
            NFetchDataD = Nothing
        Else
            NFetchDataD = cmd.ExecuteScalar()
        End If
    End Function
    Public Function NFetchData(ByVal STR As String) As String
        cmd = New OleDbCommand(STR, con)
        If IsDBNull(cmd.ExecuteScalar()) Then
            NFetchData = ""
        Else
            NFetchData = cmd.ExecuteScalar()
        End If
    End Function

    Public Sub NExcuteQuery(ByVal str As String)
        cmd = New OleDbCommand(str, con)
        cmd.ExecuteNonQuery()
    End Sub

    Public Function NAutoNumber(ByVal str As String) As Double
        'Select max(id) from Id_master
        Dim Id As Double
        Try
            cmd = New OleDbCommand(str, con)
            If IsDBNull(cmd.ExecuteScalar()) Then
                Id = 1
            Else
                Id = cmd.ExecuteScalar() + 1
            End If
            NAutoNumber = Id
        Catch
            NAutoNumber = 1
        End Try
    End Function
    Public Function NFetchDataN(ByVal STR As String) As Double
        cmd = New OleDbCommand(STR, con)
        If IsDBNull(cmd.ExecuteScalar()) Then
            NFetchDataN = 0
        Else
            NFetchDataN = cmd.ExecuteScalar()
        End If
    End Function
    Public Function NCheckRecord(ByVal str As String) As Boolean
        'select count(pd) from pada
        Dim r As Integer
        NCheckRecord = False
        cmd = New OleDbCommand(str, con)
        r = cmd.ExecuteScalar
        If r > 0 Then
            NCheckRecord = True
        Else
            NCheckRecord = False
        End If
    End Function
    Public Sub NFillDataGrid(ByVal Query As String, ByVal ctrl As DataGridView)
        Dim DT As New DataSet
        adp = New OleDbDataAdapter(Query, con)
        adp.Fill(DT)
        ctrl.DataSource = dt.Tables(0)
    End Sub
    Public Sub NFillCombo(ByVal str As String, ByVal Nvalue As String, ByVal NDisplay As String, ByVal ctrl As ComboBox)
        Dim dtp As New DataSet
        adp = New OleDbDataAdapter(str, con)
        adp.Fill(dtp)
        'ctrl.Items.Clear()

        ctrl.DataSource = dtp.Tables(0)
        ctrl.ValueMember = Nvalue
        ctrl.DisplayMember = NDisplay
        ctrl.SelectedIndex = -1
    End Sub

End Module

Imports System.Data.SqlClient
Imports System.Data.OleDb
Module ModLocalFunction

    Public con As OleDbConnection
    Private cmd As New OleDbCommand
    Private adp As New OleDbDataAdapter
    Private Trans As SqlTransaction = Nothing
    Public Sub NFormatingControl(ByVal parent As Control)
        If TypeOf parent Is Control Then
            parent.BackColor = Color.White
            parent.ForeColor = Color.Black
        End If
        For Each c As Control In parent.Controls
            If TypeOf c Is PictureBox Then
                c.BackColor = Color.White
            End If
            If TypeOf c Is TableLayoutPanel Then
                If CType(c, TableLayoutPanel).Dock = DockStyle.Fill Then
                    c.BackColor = Color.LightBlue
                Else
                    c.BackColor = Color.White
                End If
            ElseIf TypeOf c Is DataGridView Then
                CType(c, DataGridView).BackgroundColor = Color.White
            ElseIf TypeOf c Is Panel Or TypeOf c Is Button Then
                c.BackColor = Color.LightBlue
                c.ForeColor = Color.Black
            ElseIf TypeOf c Is Label Then
                If CType(c, Label).Dock = DockStyle.Top Then
                    c.BackColor = Color.LightBlue
                    c.ForeColor = Color.Black
                Else
                    c.BackColor = Color.Transparent
                End If
            ElseIf TypeOf c Is TextBox Then
                If CType(c, TextBox).ReadOnly = True Then
                    c.BackColor = Color.AliceBlue
                End If
            End If
            If TypeOf c Is Label Then
                c.ForeColor = Color.Black
            End If
            If (c.Controls.Count > 0) Then
                NFormatingControl(c)
            End If
        Next
    End Sub
    Public Sub NShowInMdi(ByVal frm As Form, ByVal mdi As Form)
        Try
            frm.Text = ""
            frm.MdiParent = mdi
            frm.MaximizeBox = False
            frm.FormBorderStyle = FormBorderStyle.FixedToolWindow
            frm.StartPosition = FormStartPosition.CenterScreen
            NFormatingControl(frm)
            'frm.ShowIcon = False
            frm.Show()
            frm.Focus()
        Catch ex As Exception
        End Try
    End Sub
    Public Sub NSetFocus(ByVal e As Integer)
        If e = 13 Or e = 9 Then
            SendKeys.Send("{TAB}")
        ElseIf e = 27 Then
            SendKeys.Send("+{TAB}")
        Else
        End If
    End Sub
    Public Sub NGridFormating(ByVal DataGrid As DataGridView)
        DataGrid.AllowUserToAddRows = False
        DataGrid.AllowUserToDeleteRows = False
        DataGrid.AllowUserToOrderColumns = False
        DataGrid.AllowUserToResizeRows = False
        DataGrid.ReadOnly = True
        DataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        DataGrid.RowsDefaultCellStyle.SelectionBackColor = Color.LightBlue
        DataGrid.RowsDefaultCellStyle.SelectionForeColor = Color.Navy
        DataGrid.AlternatingRowsDefaultCellStyle.BackColor = Color.AliceBlue
        DataGrid.EnableHeadersVisualStyles = False
        DataGrid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Raised
        DataGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.AliceBlue

        DataGrid.RowHeadersDefaultCellStyle.BackColor = Color.AliceBlue
        DataGrid.RowHeadersVisible = False
        DataGrid.Font = New Font("Verdana", 9, FontStyle.Regular)
        DataGrid.ForeColor = Color.Black
        DataGrid.ColumnHeadersDefaultCellStyle.Font = New Font("Verdana", 9, FontStyle.Bold)
    End Sub
    Public Sub NClearingControl(ByVal parent As Control)
        For Each c As Control In parent.Controls
            If (c.Controls.Count > 0) Then
                NClearingControl(c)
            Else
                If TypeOf c Is TextBox Then
                    CType(c, TextBox).Text = ""
                End If
                If TypeOf c Is ComboBox Then
                    If CType(c, ComboBox).DropDownStyle = ComboBoxStyle.DropDown Then
                        CType(c, ComboBox).Text = ""
                    Else
                        CType(c, ComboBox).SelectedIndex = -1
                    End If
                End If
                If TypeOf c Is DateTimePicker Then
                    CType(c, DateTimePicker).Value = Now
                End If
            End If
        Next
    End Sub
    Public Sub NShowDialog(ByVal frm As Form)
        frm.ShowInTaskbar = False
        frm.FormBorderStyle = FormBorderStyle.FixedToolWindow
        frm.StartPosition = FormStartPosition.CenterScreen
        NFormatingControl(frm)
        frm.ShowDialog()
        frm.Dispose()
    End Sub

    Public Sub NClearGrid(ByVal ctrl As DataGridView)
        Try
            Dim i As Integer
            For i = ctrl.Rows.Count - 1 To 0 Step -1
                ctrl.Rows.RemoveAt(i)
            Next
        Catch ex As Exception
        End Try
    End Sub
    Public Sub NFillComboWithReader(ByVal str As String, ByVal ctrl As ComboBox)
        Dim dr As OleDbDataReader
        cmd = New OleDbCommand(str, con)
        dr = cmd.ExecuteReader
        ctrl.Items.Clear()
        While dr.Read
            ctrl.Items.Add(Trim(dr.Item(0)))
        End While
        dr.Close()
    End Sub
    Public Sub NGridFormatingChild(ByVal DataGrid As DataGridView)
        DataGrid.AllowUserToAddRows = False
        DataGrid.AllowUserToDeleteRows = True
        DataGrid.AllowUserToOrderColumns = False
        DataGrid.AllowUserToResizeRows = False
        DataGrid.ReadOnly = True
        DataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        DataGrid.RowsDefaultCellStyle.SelectionBackColor = Color.LightBlue
        DataGrid.RowsDefaultCellStyle.SelectionForeColor = Color.Navy
        DataGrid.AlternatingRowsDefaultCellStyle.BackColor = Color.AliceBlue
        DataGrid.EnableHeadersVisualStyles = False
        DataGrid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Raised
        DataGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.AliceBlue
        DataGrid.RowHeadersDefaultCellStyle.BackColor = Color.AliceBlue
        DataGrid.RowHeadersVisible = False
        DataGrid.Font = New Font("Verdana", 9, FontStyle.Regular)
        DataGrid.ColumnHeadersDefaultCellStyle.Font = New Font("Verdana", 9, FontStyle.Bold)
    End Sub
End Module

Module ModVariable
    Public _RDATE As Date = Nothing
    Public _EDATE As Date = Nothing
    Public Function SaveMessage() As Boolean
        If MsgBox("Are you sure to save data...", MsgBoxStyle.Information + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton1, "Saved...") = MsgBoxResult.Yes Then
            SaveMessage = True
        Else
            SaveMessage = False
        End If
    End Function
    Public Sub InvalidMessage(ByVal msg As String)
        MsgBox(msg + " must be required..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Invalid Opration")
    End Sub
    Public Sub NAllreadyMessage(ByVal msg As String)
        MsgBox(msg + " is already exits..", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Invalid Opration")
    End Sub
    Public Function DeleteMessage() As Boolean
        If MsgBox("Data is permenent Deleted..", MsgBoxStyle.Information + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton1, "Delete...") = MsgBoxResult.Yes Then
            DeleteMessage = True
        Else
            DeleteMessage = False
        End If
    End Function

    
End Module

Module ModSample
    Public Sub FillAcCombo(ByVal CTRL As ComboBox)
        NFillCombo("SELECT SRNO, INAME FROM MST_ITEM  ORDER BY INAME", "SRNO", "INAME", CTRL)
    End Sub

End Module

Public Class FrmLogin

    Private Sub FrmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' NFormatingControl1(Me)
        ConnectionOpen()
        _RDATE = NFetchDataD("SELECT RDATE FROM OPT_RDATE WHERE SRNO=1")
        _EDATE = NFetchDataD("SELECT EDATE FROM OPT_RDATE WHERE SRNO=1")
    End Sub
    Private Sub TxtUName_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtUName.KeyDown, TxtPass.KeyDown, CmdOk.KeyDown, CmdCancel.KeyDown
        NSetFocus(e.KeyValue)
        If sender.Equals(TxtUName) = True And e.KeyValue = 27 Then Me.Close()
    End Sub

    Private Sub Cmd_Ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdOk.Click
        Dim CDate1 As Date = Now.Date
        Dim DYEAR As String = DateDiff(DateInterval.Year, _RDATE, _EDATE)
        Dim dt As New DataSet
        dt = NFetchDataset("SELECT UNAME, PASS FROM OPT_LOGIN WHERE SRNO =" & Trim(Val(1)) & "")

        If dt.Tables(0).Rows.Count <> 0 Then
            If dt.Tables(0).Rows(0).Item(0).ToString = TxtUName.Text And TxtPass.Text = dt.Tables(0).Rows(0).Item(1).ToString Then
                Dim frm As New MainForm



                Me.Hide()
                frm.ShowDialog()
            Else
                MsgBox("Password is incorrect try again....", MsgBoxStyle.Information, "Invalid")
                Exit Sub
            End If
            'MsgBox("Password is incorrect try again....", MsgBoxStyle.Information, "Invalid")
            Exit Sub
        End If
    End Sub

    Private Sub Cmd_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdCancel.Click
        Me.Close()
    End Sub

    
End Class

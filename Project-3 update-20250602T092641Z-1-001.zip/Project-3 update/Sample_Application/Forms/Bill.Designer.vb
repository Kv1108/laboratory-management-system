<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Bill
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.TxtDis = New System.Windows.Forms.TextBox
        Me.TbMain = New System.Windows.Forms.TableLayoutPanel
        Me.CmbTNo = New System.Windows.Forms.ComboBox
        Me.TxtName = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.DtDate = New System.Windows.Forms.DateTimePicker
        Me.Label8 = New System.Windows.Forms.Label
        Me.TxtSrNo = New System.Windows.Forms.TextBox
        Me.CmbRName = New System.Windows.Forms.ComboBox
        Me.DataItem = New System.Windows.Forms.DataGridView
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txtgtotal = New System.Windows.Forms.TextBox
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel
        Me.CmdExit = New System.Windows.Forms.Button
        Me.CmdCancel = New System.Windows.Forms.Button
        Me.CmdDelete = New System.Windows.Forms.Button
        Me.CmdSave = New System.Windows.Forms.Button
        Me.TbChild = New System.Windows.Forms.TableLayoutPanel
        Me.TxtSTotal = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.LblDis = New System.Windows.Forms.Label
        Me.TxtRate = New System.Windows.Forms.TextBox
        Me.CmdAdd = New System.Windows.Forms.Button
        Me.CmdCancel1 = New System.Windows.Forms.Button
        Me.TbMain.SuspendLayout()
        CType(Me.DataItem, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.TbChild.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(167, 27)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Report Name"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(357, 21)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(540, 27)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Rate"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 21)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Bill No."
        '
        'TxtDis
        '
        Me.TxtDis.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TxtDis.Location = New System.Drawing.Point(806, 23)
        Me.TxtDis.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtDis.Name = "TxtDis"
        Me.TxtDis.Size = New System.Drawing.Size(101, 27)
        Me.TxtDis.TabIndex = 7
        '
        'TbMain
        '
        Me.TbMain.BackColor = System.Drawing.Color.SkyBlue
        Me.TbMain.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetPartial
        Me.TbMain.ColumnCount = 6
        Me.TbMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.70652!))
        Me.TbMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 69.29348!))
        Me.TbMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 81.0!))
        Me.TbMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 506.0!))
        Me.TbMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70.0!))
        Me.TbMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 234.0!))
        Me.TbMain.Controls.Add(Me.Label1, 0, 0)
        Me.TbMain.Controls.Add(Me.CmbTNo, 1, 0)
        Me.TbMain.Controls.Add(Me.Label2, 2, 0)
        Me.TbMain.Controls.Add(Me.TxtName, 3, 0)
        Me.TbMain.Controls.Add(Me.Label7, 4, 0)
        Me.TbMain.Controls.Add(Me.DtDate, 5, 0)
        Me.TbMain.Font = New System.Drawing.Font("Arial Rounded MT Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TbMain.Location = New System.Drawing.Point(34, 13)
        Me.TbMain.Margin = New System.Windows.Forms.Padding(4)
        Me.TbMain.Name = "TbMain"
        Me.TbMain.RowCount = 1
        Me.TbMain.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TbMain.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60.0!))
        Me.TbMain.Size = New System.Drawing.Size(1241, 63)
        Me.TbMain.TabIndex = 5
        '
        'CmbTNo
        '
        Me.CmbTNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.CmbTNo.FormattingEnabled = True
        Me.CmbTNo.Location = New System.Drawing.Point(110, 19)
        Me.CmbTNo.Name = "CmbTNo"
        Me.CmbTNo.Size = New System.Drawing.Size(220, 28)
        Me.CmbTNo.TabIndex = 12
        '
        'TxtName
        '
        Me.TxtName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TxtName.Location = New System.Drawing.Point(425, 18)
        Me.TxtName.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtName.Name = "TxtName"
        Me.TxtName.Size = New System.Drawing.Size(489, 27)
        Me.TxtName.TabIndex = 8
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(948, 21)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 20)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Date"
        '
        'DtDate
        '
        Me.DtDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.DtDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DtDate.Location = New System.Drawing.Point(1006, 18)
        Me.DtDate.Name = "DtDate"
        Me.DtDate.Size = New System.Drawing.Size(186, 27)
        Me.DtDate.TabIndex = 11
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 27)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 20)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "Sr.No."
        '
        'TxtSrNo
        '
        Me.TxtSrNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TxtSrNo.Location = New System.Drawing.Point(83, 23)
        Me.TxtSrNo.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtSrNo.Name = "TxtSrNo"
        Me.TxtSrNo.Size = New System.Drawing.Size(67, 27)
        Me.TxtSrNo.TabIndex = 14
        '
        'CmbRName
        '
        Me.CmbRName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.CmbRName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbRName.FormattingEnabled = True
        Me.CmbRName.Location = New System.Drawing.Point(295, 24)
        Me.CmbRName.Margin = New System.Windows.Forms.Padding(4)
        Me.CmbRName.Name = "CmbRName"
        Me.CmbRName.Size = New System.Drawing.Size(218, 28)
        Me.CmbRName.TabIndex = 9
        '
        'DataItem
        '
        Me.DataItem.BackgroundColor = System.Drawing.Color.White
        Me.DataItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataItem.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6})
        Me.DataItem.Location = New System.Drawing.Point(34, 162)
        Me.DataItem.Margin = New System.Windows.Forms.Padding(4)
        Me.DataItem.Name = "DataItem"
        Me.DataItem.RowTemplate.Height = 24
        Me.DataItem.Size = New System.Drawing.Size(1241, 262)
        Me.DataItem.TabIndex = 6
        '
        'Column1
        '
        Me.Column1.HeaderText = "Sr.No."
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "Report Name"
        Me.Column2.Name = "Column2"
        Me.Column2.Width = 700
        '
        'Column3
        '
        Me.Column3.HeaderText = "Rno"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "Rate"
        Me.Column4.Name = "Column4"
        '
        'Column5
        '
        Me.Column5.HeaderText = "Discount"
        Me.Column5.Name = "Column5"
        '
        'Column6
        '
        Me.Column6.HeaderText = "Total"
        Me.Column6.Name = "Column6"
        Me.Column6.Width = 200
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 83.58662!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.41337!))
        Me.TableLayoutPanel2.Controls.Add(Me.Label6, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Txtgtotal, 1, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(34, 429)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1241, 52)
        Me.TableLayoutPanel2.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Rounded MT Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(5, 16)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(111, 20)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Grand Total:"
        '
        'Txtgtotal
        '
        Me.Txtgtotal.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Txtgtotal.Enabled = False
        Me.Txtgtotal.Font = New System.Drawing.Font("Arial Rounded MT Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtgtotal.Location = New System.Drawing.Point(1040, 12)
        Me.Txtgtotal.Margin = New System.Windows.Forms.Padding(4)
        Me.Txtgtotal.Name = "Txtgtotal"
        Me.Txtgtotal.Size = New System.Drawing.Size(157, 27)
        Me.Txtgtotal.TabIndex = 1
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.BackColor = System.Drawing.Color.SkyBlue
        Me.TableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel3.ColumnCount = 4
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.CmdExit, 3, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.CmdCancel, 2, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.CmdDelete, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.CmdSave, 0, 0)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(34, 491)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(1241, 63)
        Me.TableLayoutPanel3.TabIndex = 8
        '
        'CmdExit
        '
        Me.CmdExit.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.CmdExit.Location = New System.Drawing.Point(1028, 8)
        Me.CmdExit.Name = "CmdExit"
        Me.CmdExit.Size = New System.Drawing.Size(115, 47)
        Me.CmdExit.TabIndex = 4
        Me.CmdExit.Text = "Exit"
        Me.CmdExit.UseVisualStyleBackColor = True
        '
        'CmdCancel
        '
        Me.CmdCancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.CmdCancel.Location = New System.Drawing.Point(718, 8)
        Me.CmdCancel.Name = "CmdCancel"
        Me.CmdCancel.Size = New System.Drawing.Size(115, 47)
        Me.CmdCancel.TabIndex = 2
        Me.CmdCancel.Text = "Cancel"
        Me.CmdCancel.UseVisualStyleBackColor = True
        '
        'CmdDelete
        '
        Me.CmdDelete.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.CmdDelete.Location = New System.Drawing.Point(408, 8)
        Me.CmdDelete.Name = "CmdDelete"
        Me.CmdDelete.Size = New System.Drawing.Size(115, 47)
        Me.CmdDelete.TabIndex = 1
        Me.CmdDelete.Text = "Delete"
        Me.CmdDelete.UseVisualStyleBackColor = True
        '
        'CmdSave
        '
        Me.CmdSave.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.CmdSave.Location = New System.Drawing.Point(98, 8)
        Me.CmdSave.Name = "CmdSave"
        Me.CmdSave.Size = New System.Drawing.Size(115, 47)
        Me.CmdSave.TabIndex = 0
        Me.CmdSave.Text = "Save"
        Me.CmdSave.UseVisualStyleBackColor = True
        '
        'TbChild
        '
        Me.TbChild.BackColor = System.Drawing.Color.SkyBlue
        Me.TbChild.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetPartial
        Me.TbChild.ColumnCount = 10
        Me.TbChild.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 73.0!))
        Me.TbChild.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TbChild.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 131.0!))
        Me.TbChild.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 226.0!))
        Me.TbChild.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 71.0!))
        Me.TbChild.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 104.0!))
        Me.TbChild.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 98.0!))
        Me.TbChild.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 109.0!))
        Me.TbChild.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 73.0!))
        Me.TbChild.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 138.0!))
        Me.TbChild.Controls.Add(Me.Label8, 0, 0)
        Me.TbChild.Controls.Add(Me.TxtSTotal, 9, 0)
        Me.TbChild.Controls.Add(Me.Label4, 8, 0)
        Me.TbChild.Controls.Add(Me.LblDis, 6, 0)
        Me.TbChild.Controls.Add(Me.TxtSrNo, 1, 0)
        Me.TbChild.Controls.Add(Me.Label5, 4, 0)
        Me.TbChild.Controls.Add(Me.CmbRName, 3, 0)
        Me.TbChild.Controls.Add(Me.Label3, 2, 0)
        Me.TbChild.Controls.Add(Me.TxtDis, 7, 0)
        Me.TbChild.Controls.Add(Me.TxtRate, 5, 0)
        Me.TbChild.Location = New System.Drawing.Point(34, 80)
        Me.TbChild.Name = "TbChild"
        Me.TbChild.RowCount = 1
        Me.TbChild.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TbChild.Size = New System.Drawing.Size(1131, 74)
        Me.TbChild.TabIndex = 9
        '
        'TxtSTotal
        '
        Me.TxtSTotal.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TxtSTotal.Location = New System.Drawing.Point(994, 23)
        Me.TxtSTotal.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtSTotal.Name = "TxtSTotal"
        Me.TxtSTotal.ReadOnly = True
        Me.TxtSTotal.Size = New System.Drawing.Size(109, 27)
        Me.TxtSTotal.TabIndex = 13
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(932, 27)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 20)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Total"
        '
        'LblDis
        '
        Me.LblDis.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.LblDis.AutoSize = True
        Me.LblDis.Location = New System.Drawing.Point(713, 27)
        Me.LblDis.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblDis.Name = "LblDis"
        Me.LblDis.Size = New System.Drawing.Size(82, 20)
        Me.LblDis.TabIndex = 10
        Me.LblDis.Text = "Discount"
        '
        'TxtRate
        '
        Me.TxtRate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TxtRate.Location = New System.Drawing.Point(598, 23)
        Me.TxtRate.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtRate.Name = "TxtRate"
        Me.TxtRate.Size = New System.Drawing.Size(96, 27)
        Me.TxtRate.TabIndex = 11
        '
        'CmdAdd
        '
        Me.CmdAdd.Location = New System.Drawing.Point(1171, 80)
        Me.CmdAdd.Name = "CmdAdd"
        Me.CmdAdd.Size = New System.Drawing.Size(104, 37)
        Me.CmdAdd.TabIndex = 10
        Me.CmdAdd.Text = "Add"
        Me.CmdAdd.UseVisualStyleBackColor = True
        '
        'CmdCancel1
        '
        Me.CmdCancel1.Location = New System.Drawing.Point(1171, 120)
        Me.CmdCancel1.Name = "CmdCancel1"
        Me.CmdCancel1.Size = New System.Drawing.Size(104, 37)
        Me.CmdCancel1.TabIndex = 11
        Me.CmdCancel1.Text = "Cancel"
        Me.CmdCancel1.UseVisualStyleBackColor = True
        '
        'Bill
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(1299, 559)
        Me.Controls.Add(Me.CmdCancel1)
        Me.Controls.Add(Me.CmdAdd)
        Me.Controls.Add(Me.TbChild)
        Me.Controls.Add(Me.TableLayoutPanel3)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.DataItem)
        Me.Controls.Add(Me.TbMain)
        Me.Font = New System.Drawing.Font("Arial Rounded MT Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Bill"
        Me.Text = "Bill"
        Me.TbMain.ResumeLayout(False)
        Me.TbMain.PerformLayout()
        CType(Me.DataItem, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TbChild.ResumeLayout(False)
        Me.TbChild.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtDis As System.Windows.Forms.TextBox
    Friend WithEvents TbMain As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TxtName As System.Windows.Forms.TextBox
    Friend WithEvents CmbRName As System.Windows.Forms.ComboBox
    Friend WithEvents DataItem As System.Windows.Forms.DataGridView
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txtgtotal As System.Windows.Forms.TextBox
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents CmdExit As System.Windows.Forms.Button
    Friend WithEvents CmdCancel As System.Windows.Forms.Button
    Friend WithEvents CmdDelete As System.Windows.Forms.Button
    Friend WithEvents CmdSave As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TbChild As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents CmdAdd As System.Windows.Forms.Button
    Friend WithEvents CmdCancel1 As System.Windows.Forms.Button
    Friend WithEvents LblDis As System.Windows.Forms.Label
    Friend WithEvents TxtRate As System.Windows.Forms.TextBox
    Friend WithEvents DtDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents TxtSTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents CmbTNo As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TxtSrNo As System.Windows.Forms.TextBox
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class

Public Class Bill
    Dim AddFlag As Int16
    Dim EditFlag As Int16
    Dim AFlag As Int16
    Dim EFlag As Int16
    Dim crow As Integer
    Dim UNO As Integer
    

    Private Sub CmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdCancel.Click
        CmbTNo.Text = 0
        AddFlag = 1
        EditFlag = 0

        NClearingControl(TbMain)
        NClearingControl(TbChild)
        CmbTNo.Focus()
        NClearGrid(DataItem)
        Autonumber()
        '  DisplayGrid()
    End Sub
   
    Public Sub DisplayGrid()
        Dim DT As New DataSet
        Dim I As Integer
        DT = NFetchDataset("SELECT T.SRNO, I.INAME,I.SRNO, T.RATE, T.DISCOUNT, T.TOTAL FROM TNS_SALE T, MST_SALE M,MST_ITEM I WHERE I.SRNO=T.RNAME AND T.BILLNO= M.BILLNO AND T.BILLNO=" & Trim(Val(CmbTNo.Text)) & "")
        NClearGrid(DataItem)
        For I = 0 To DT.Tables(0).Rows.Count - 1
            DataItem.Rows.Add()
            DataItem.Item(0, I).Value = DT.Tables(0).Rows(I).Item(0) 'BILLNO
            DataItem.Item(1, I).Value = DT.Tables(0).Rows(I).Item(1)  'RNAME
            DataItem.Item(2, I).Value = DT.Tables(0).Rows(I).Item(2)  'RNO
            DataItem.Item(3, I).Value = DT.Tables(0).Rows(I).Item(3) 'RATE
            DataItem.Item(4, I).Value = DT.Tables(0).Rows(I).Item(4) 'DISCOUNT
            DataItem.Item(5, I).Value = DT.Tables(0).Rows(I).Item(5) 'TOTAL
        Next
        ShowTotal()

    End Sub

    Private Sub CmdCancel1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdCancel1.Click
        
        NClearingControl(TbChild)
        AFlag = 1
        EFlag = 0
        CmbRName.Focus()
        '  DisplayGrid()
        '  Autonumber()

    End Sub

    Private Sub CmdAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdAdd.Click
        Dim i As Integer
        If Valid1() = True Then
            If AFlag = 1 Then
                DataItem.Rows.Add()
                i = DataItem.Rows.Count - 1
                DataItem.Item(0, i).Value = i + 1
                DataItem.Item(1, i).Value = CmbRName.Text
                DataItem.Item(2, i).Value = CmbRName.SelectedValue
                DataItem.Item(3, i).Value = Val(TxtRate.Text)
                DataItem.Item(4, i).Value = Val(TxtDis.Text)
                DataItem.Item(5, i).Value = Val(TxtSTotal.Text)

            Else
                DataItem.Item(0, crow).Value = i + 1
                DataItem.Item(1, crow).Value = CmbRName.Text
                DataItem.Item(2, crow).Value = CmbRName.SelectedValue
                DataItem.Item(3, crow).Value = Val(TxtRate.Text)
                DataItem.Item(4, crow).Value = Val(TxtDis.Text)
                DataItem.Item(5, crow).Value = Val(TxtSTotal.Text)
            End If
            ShowTotal()
            NClearingControl(TbChild)
            CmbRName.Focus()
            AFlag = 1
            EFlag = 0
        End If

    End Sub
    Public Function Valid1() As Boolean
        Valid1 = True
        If CmbRName.Text = "" Then
            Valid1 = False
            CmbRName.Focus()
            InvalidMessage("Product Name")
            Exit Function
        End If
        'If TxtRate.Text = "" Then TxtRate.Text = 0
        'If TxtDis.Text - "" Then TxtDis.Text = 0

    End Function
    Public Sub ShowTotal()
        Dim i As Integer
        TxtRate.Text = 0
        TxtSTotal.Text = 0
        For i = 0 To DataItem.Rows.Count - 1
            ' TxtRate.Text = Val(TxtRate.Text) + DataItem.Rows(i).Cells(3).Value
            Txtgtotal.Text = Format(Val(TxtSTotal.Text) + DataItem.Rows(i).Cells(5).Value, "0.00")
        Next

    End Sub
    Private Sub CmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSave.Click
        Dim sql1 As String

        If Valid() = True Then
            If SaveMessage() = True Then
                If EditFlag = 1 Then
                    sql1 = "UPDATE MST_SALE SET IDATE=#" & Format(DtDate.Value, "MM/dd/yyyy") & "# , " _
                     + " PNAME='" & Trim(UCase(TxtName.Text)) & "', " _
                     + " STOTAL=" & Trim(Val(Txtgtotal.Text)) & " WHERE BILLNO=" & Trim(Val(CmbTNo.Text)) & ""
                Else
                    CmbTNo.Text = NAutoNumber("SELECT MAX(BILLNO) FROM MST_SALE")
                    sql1 = "INSERT INTO MST_SALE(BILLNO,IDATE,PNAME,STOTAL)VALUES(" _
                    + " " & Trim(Val(CmbTNo.Text)) & ",#" & Format(DtDate.Value, "MM/dd/yyyy") & "# ,'" & Trim(UCase(TxtName.Text)) & "'," & Trim(Val(Txtgtotal.Text)) & ")"
                End If
                TransData()
                NExcuteQuery(sql1)

                Call CmdCancel_Click(sender, e)
            End If
        End If
    End Sub
    Public Sub TransData()
        Dim i As Integer
        Dim sql As String
        DeleteTransData()
        For i = 0 To DataItem.Rows.Count - 1
            sql = "INSERT INTO TNS_SALE (BILLNO,SRNO,RNAME,RATE,DISCOUNT,TOTAL)VALUES( " _
            + " " & Trim(Val(CmbTNo.Text)) & ", " & i + 1 & "," & Trim(Val(DataItem.Rows(i).Cells(2).Value)) & ", " _
            + " " & Trim(Val(DataItem.Rows(i).Cells(3).Value)) & ", " & Trim(Val(DataItem.Rows(i).Cells(4).Value)) & ", " _
            + " " & Trim(Val(DataItem.Rows(i).Cells(5).Value)) & ")"
            NExcuteQuery(sql)
        Next
    End Sub
    Public Sub DeleteTransData()
        NExcuteQuery("DELETE * FROM TNS_SALE WHERE BILLNO=" & Trim(Val(CmbTNo.Text)) & "")
    End Sub
    Public Function Valid() As Boolean
        Valid = True
        If CmbTNo.Text = "" Then
            Valid = False
            CmdCancel.Focus()
            InvalidMessage("Bill No")
            Exit Function
        End If

    End Function
    Private Sub CmdExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdExit.Click
        Me.Close()
    End Sub
    Public Sub Autonumber()
        CmbTNo.Text = NAutoNumber("SELECT MAX(BILLNO) FROM MST_SALE ")
    End Sub
    Private Sub CmbRName_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles CmbTNo.KeyDown, CmbRName.KeyDown, DtDate.KeyDown, TxtDis.KeyDown, TxtRate.KeyDown, CmdAdd.KeyDown, CmdCancel1.KeyDown, CmdSave.KeyDown, CmdDelete.KeyDown, CmdCancel.KeyDown, CmdExit.KeyDown, TxtSTotal.KeyDown
        If sender.Equals(CmbTNo) = True And e.KeyValue = 27 Then Me.Close()
        If sender.Equals(CmbRName) = True And e.KeyValue = 116 Then
            NShowDialog(FrmMasterItem)
        End If
        NSetFocus(e.KeyValue)
    End Sub
    Private Sub Bill_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        NGridFormatingChild(DataItem)
        NFillCombo("SELECT SRNO,INAME FROM MST_ITEM ORDER BY INAME", "SRNO", "INAME", CmbRName)
        CmdCancel_Click(sender, e)
    End Sub

    Private Sub CmbTNo_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles CmbTNo.LostFocus
        If NCheckRecord("SELECT * FROM MST_SALE WHERE BILLNO=" & Trim(Val(CmbTNo.Text)) & " ") = True Then

            EditFlag = 1
            AddFlag = 0
            AFlag = 1
            EFlag = 0
            DisplayAllData()
            DisplayGrid()
            
        Else


            Dim tmp As Double = Val(CmbTNo.Text)
            AddFlag = 1
            EditFlag = 0
            AFlag = 1
            EFlag = 0
            NClearingControl(TbChild)
            NClearingControl(TbMain)
            TxtSrNo.Text = 0
            NClearGrid(DataItem)
            ShowTotal()
            CmbTNo.Text = tmp
        End If
    End Sub
    Public Sub DisplayAllData()
        Dim DT As New DataSet
        DT = NFetchDataset("SELECT IDATE,PNAME,STOTAL FROM MST_SALE WHERE BILLNO=" & Trim(Val(CmbTNo.Text)) & " ")
        If DT.Tables(0).Rows.Count > 0 Then

            DtDate.Value = DT.Tables(0).Rows(0).Item(0)
            TxtName.Text = DT.Tables(0).Rows(0).Item(1)
            Txtgtotal.Text = Format(DT.Tables(0).Rows(0).Item(2), "0.00")

        End If
    End Sub
    Private Sub DataItem_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataItem.CellDoubleClick
        If IsDBNull(DataItem.CurrentRow.Cells(0).Value) Then Exit Sub
        EFlag = 1
        AFlag = 0
        crow = DataItem.CurrentRow.Index
        TxtSrNo.Text = DataItem.CurrentRow.Cells(0).Value
        CmbRName.Text = DataItem.CurrentRow.Cells(1).Value
        TxtRate.Text = DataItem.CurrentRow.Cells(3).Value
        TxtDis.Text = DataItem.CurrentRow.Cells(4).Value
        TxtSTotal.Text = DataItem.CurrentRow.Cells(5).Value
        CmbRName.Focus()
    End Sub

    Private Sub TxtRate_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtRate.TextChanged
        TxtSTotal.Text = Val(TxtRate.Text) - Val(TxtDis.Text)
    End Sub
End Class